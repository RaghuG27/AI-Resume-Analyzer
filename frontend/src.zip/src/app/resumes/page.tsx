"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, FileText, RefreshCw, Sparkles, UploadCloud } from "lucide-react";
import AppShell from "@/components/layout/AppShell";
import ResumeUploader from "@/components/resume/ResumeUploader";
import { getResumes, ResumeResponse } from "@/lib/resume";

export default function ResumesPage() {
  const [resumes, setResumes] = useState<ResumeResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      setResumes(await getResumes());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load resumes.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  return (
    <AppShell>
      <div className="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
        <Link href="/dashboard" className="mb-6 inline-flex items-center gap-2 text-sm text-slate-500 hover:text-slate-900">
          <ArrowLeft size={15} /> Dashboard
        </Link>
        <div className="mb-7">
          <div className="icon-tile flex h-12 w-12"><UploadCloud size={22} /></div>
          <h1 className="mt-4 text-3xl font-bold text-slate-900">Your resumes</h1>
          <p className="mt-2 text-sm text-slate-500">Upload PDF or DOCX resumes and use them for job matching and candidate profile extraction.</p>
        </div>

        <section className="panel p-5 sm:p-7">
          <h2 className="mb-4 font-semibold text-slate-900">Upload a resume</h2>
          <ResumeUploader onUploaded={() => void load()} />
        </section>

        <section className="mt-8">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-slate-900">Uploaded files</h2>
              <p className="text-sm text-slate-500">Resumes associated with your account.</p>
            </div>
            <button onClick={() => void load()} className="btn-ghost" disabled={loading}>
              <RefreshCw size={15} className={loading ? "animate-spin" : ""} /> Refresh
            </button>
          </div>
          {error && <div className="mb-4 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>}
          {loading ? <p className="py-10 text-center text-sm text-slate-500">Loading resumes...</p> :
            resumes.length === 0 ? <div className="panel p-8 text-center text-sm text-slate-500">No resumes uploaded yet.</div> :
            <div className="space-y-3">
              {resumes.map((resume) => (
                <div key={resume.id} className="panel flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="icon-tile flex h-10 w-10 shrink-0"><FileText size={18} /></div>
                    <div className="min-w-0">
                      <p className="truncate font-medium text-slate-900">{resume.original_filename}</p>
                      <p className="mt-1 text-xs text-slate-400">{new Date(resume.created_at).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button onClick={() => window.location.assign(`/analyses/new?resumeId=${resume.id}`)} className="btn-ghost">
                      <Sparkles size={15} /> Analyze
                    </button>
                    <button onClick={() => window.location.assign(`/candidates?resumeId=${resume.id}`)} className="btn-primary">
                      Create candidate profile
                    </button>
                  </div>
                </div>
              ))}
            </div>
          }
        </section>
      </div>
    </AppShell>
  );
}
