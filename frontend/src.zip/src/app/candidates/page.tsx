"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { FileUser, RefreshCw, Sparkles, Trash2 } from "lucide-react";
import AppShell from "@/components/layout/AppShell";
import { CandidateProfile, deleteCandidate, extractCandidateFromResume, getCandidates } from "@/lib/candidates";
import { getResumes, ResumeResponse } from "@/lib/resume";

function CandidatesContent() {
  const searchParams = useSearchParams();
  const [items, setItems] = useState<CandidateProfile[]>([]);
  const [resumes, setResumes] = useState<ResumeResponse[]>([]);
  const [resumeId, setResumeId] = useState(searchParams.get("resumeId") ?? "");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function load() {
    setLoading(true); setError("");
    try {
      const [profiles, files] = await Promise.all([getCandidates(search), getResumes()]);
      setItems(profiles); setResumes(files);
      if (!resumeId && files.length) setResumeId(files[0].id);
    } catch (err) { setError(err instanceof Error ? err.message : "Could not load candidate profiles."); }
    finally { setLoading(false); }
  }
  useEffect(() => { void load(); }, [search]);

  async function extract() {
    if (!resumeId) return setError("Upload and select a resume first.");
    setBusy(true); setError(""); setNotice("");
    try {
      const candidate = await extractCandidateFromResume(resumeId);
      setNotice(`Candidate profile extracted for ${candidate.full_name}.`);
      await load();
    } catch (err) { setError(err instanceof Error ? err.message : "Profile extraction failed."); }
    finally { setBusy(false); }
  }

  async function remove(id: string) {
    try { await deleteCandidate(id); setItems((old) => old.filter((item) => item.id !== id)); }
    catch (err) { setError(err instanceof Error ? err.message : "Could not delete candidate."); }
  }

  return (
    <AppShell>
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        <div className="mb-7"><div className="icon-tile flex h-12 w-12"><FileUser size={22} /></div><h1 className="mt-4 text-3xl font-bold text-slate-900">Candidate profiles</h1><p className="mt-2 text-sm text-slate-500">Extract a candidate profile from one of your uploaded resumes and manage your candidate records.</p></div>
        <section className="panel mb-6 p-5">
          <h2 className="font-semibold text-slate-900">Extract from resume</h2>
          <p className="mt-1 text-sm text-slate-500">The backend extracts profile information from the resume and reuses an existing profile linked to the same resume.</p>
          <div className="mt-4 flex flex-col gap-3 sm:flex-row"><select value={resumeId} onChange={(e) => setResumeId(e.target.value)} className="field h-11 flex-1 px-3 text-sm"><option value="">Select a resume</option>{resumes.map((r) => <option key={r.id} value={r.id}>{r.original_filename}</option>)}</select><button onClick={() => void extract()} disabled={busy || !resumeId} className="btn-primary"><Sparkles size={16} />{busy ? "Extracting..." : "Extract profile"}</button></div>
        </section>
        {error && <div className="mb-4 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>}
        {notice && <div className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800">{notice}</div>}
        <div className="mb-4 flex flex-col gap-3 sm:flex-row"><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, email, or current title..." className="field h-11 px-3 text-sm" /><button onClick={() => void load()} className="btn-ghost"><RefreshCw size={15} /> Refresh</button></div>
        {loading ? <p className="py-12 text-center text-sm text-slate-500">Loading profiles...</p> :
          !items.length ? <div className="panel p-10 text-center text-sm text-slate-500">No candidate profiles found.</div> :
          <div className="grid gap-4 md:grid-cols-2">{items.map((c) => <article key={c.id} className="panel p-5"><div className="flex items-start justify-between gap-3"><div><h2 className="font-semibold text-slate-900">{c.full_name}</h2><p className="mt-1 text-sm text-slate-500">{c.current_title || "Title not provided"}</p></div><button onClick={() => void remove(c.id)} className="rounded-lg p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label="Delete candidate"><Trash2 size={16} /></button></div>{c.email && <p className="mt-3 text-sm text-slate-600">{c.email}</p>}<p className="mt-2 text-xs text-slate-500">Experience: {c.experience_years ?? "Not specified"} years</p>{c.skills?.length ? <div className="mt-4 flex flex-wrap gap-2">{c.skills.map((s) => <span key={s} className="chip">{s}</span>)}</div> : null}<p className="mt-4 truncate text-[11px] text-slate-400">Profile ID: {c.id}</p></article>)}</div>
        }
      </div>
    </AppShell>
  );
}

export default function CandidatesPage() {
  return <Suspense fallback={<div className="p-10 text-center">Loading candidates...</div>}><CandidatesContent /></Suspense>;
}
